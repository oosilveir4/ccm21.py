# py-ccm21
Python Library to access a Midea CCM21 data converter
